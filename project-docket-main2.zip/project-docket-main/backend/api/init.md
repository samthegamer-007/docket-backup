ich bin samuel
